

import React from "react";
export default function Test(){
    return(
        <div className="w-[50rem] h-[40rem] bg-gray-500">
                  tfl utuyitu yvoyi uiyiu yu utuit utut 
        </div>
    )
}
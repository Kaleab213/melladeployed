import { Input, Text } from "@chakra-ui/react";
import React from "react";
import styles from "../style";
// import { Text, Input } from "@chakra-ui/react";

const CustomerInput = ({ question, onChange, value }) => {
  return (
    <>
      <div
        style={{
          width: "50vw",
          height: "1px",
          backgroundColor: "rgba(255, 255, 255, 0.36)",
          margin: "2.5rem 0",
        }}
      ></div>
      <form action="/send-email">
        <label htmlFor="name">
          {/* <Text fontSize={"2rem"} my={3}> */}
          <div className="text-2xl">{question}</div>
          {/* </Text> */}
        </label>
        <Input
          id="name"
          variant="unstyled"
          placeholder="Jhon Doe*"
          fontSize={"2xl"}
          onChange={onChange}
          value={value}
        />
      </form>
    </>
  );
};

export default CustomerInput;

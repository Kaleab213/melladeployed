import { Avatar, Box, Flex, Stack, Text, WrapItem } from "@chakra-ui/react";
import { motion } from "framer-motion";
import Navbar from "../components/Navbar";
import CustomerInput from "../components/CustomerInput";
import Socials from "../components/Socials";
import { useState } from "react";
import MyCircle from "../components/MyCircle";
import { Footer } from "../components";
import Button from "../components/Button";
import styles from "../style";

const MotionBox = motion.div;

function AboutMe() {
  const [mail, setMail] = useState({
    recipient: "",
    subject: "",
    message: "",
  });

  const handleEmail = (e) => {
    const { value: email } = e.target;
    setMail((p) => {
      return { ...p, recipient: email };
    });
    console.log(email);
  };
  const handleSubject = (e) => {
    const { value: subject } = e.target;
    setMail((p) => {
      return { ...p, subject: subject };
    });
  };
  const handleMessage = (e) => {
    const { value: message } = e.target;
    setMail((p) => {
      return { ...p, message: message };
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);

    formData.append("access_key", "e1ec6095-bd4f-4f14-8e37-a7a2ebcfe5e8");

    const object = Object.fromEntries(formData);
    const json = JSON.stringify(object);

    const res = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: json,
    }).then((res) => res.json());

    if (res.success) {
      console.log("Success", res);
      console.log(mail);
    }
  };

  return (
    <>
      <div style={{ background: "rgba(0, 0, 0, 0.93)" }}>
        <Navbar />
      </div>
      <Box
        className="bg-primary overflow-x-hidden p-[2rem] "
        color={"white"}
        display={"flex"}
        flexDirection={"column"}
        alignItems={"center"}
        justifyContent={"center"}
      >
        <Box flex={["1", "3"]}>
          <Box
            display={"flex"}
            marginTop={20}
            marginBottom={20}
            height={"fit-content"}
            // Responsive width using Chakra UI's responsive props
            px={["1rem", "1rem"]} // Responsive padding using Chakra UI's responsive props
            flexDirection={["column", "row"]} // Responsive flexDirection using Chakra UI's responsive props
            alignItems={["center", "start"]} // Responsive alignItems using Chakra UI's responsive props
          >
            <Text className="text-4xl font-bold font-poppins">
              Let's Start a
            </Text>
            <Text className="text-4xl font-bold font-poppins">
              Project Together
            </Text>
            <WrapItem alignItems={"center"} px={10}>
              <Avatar
                size={"lg"}
                name="Kola Tioluwani"
                src="https://bit.ly/tioluwani-kolawole"
              />
            </WrapItem>
          </Box>
          <CustomerInput
            question={"What is your email?"}
            onChange={handleEmail}
            value={mail.recipient}
          />
          <CustomerInput
            question={"What services are you looking for?"}
            onChange={handleSubject}
            value={mail.subject}
          />
          <CustomerInput
            question={"Write a message."}
            onChange={handleMessage}
            value={mail.message}
          />
        </Box>
        <Flex width={["90vw", "60vw"]} justifyContent={"center"} mb={"10rem"}>
          <form onSubmit={handleSubmit}>
            <Box display={"flex"} alignItems={"center"}>
              <input
                type="hidden"
                name="access_key"
                value="e1ec6095-bd4f-4f14-8e37-a7a2ebcfe5e8"
              />

              <Box className="mt-[5rem]">
                {/* <button type="submit" onClick={handleSubmit}>
                  Start
                </button> */}
                <motion.button
                  type="submit"
                  className={`py-4 px-6 font-poppins font-medium text-[18px] text-primary bg-[#F4CE14] rounded-[10px] outline-none ${styles}`}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  onClick={handleSubmit}
                >
                  Get Started
                </motion.button>
              </Box>
            </Box>
          </form>
        </Flex>
      </Box>
      <Footer />
    </>
  );
}

export default AboutMe;
